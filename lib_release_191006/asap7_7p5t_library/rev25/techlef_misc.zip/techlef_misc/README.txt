This techlef produces just a few DRCs at good (> 75%) cell density on our test cases.
The tcl files are examples on how to set up power rails gridded at each layer, which
are consistent with the design rules and SADP gridding.
