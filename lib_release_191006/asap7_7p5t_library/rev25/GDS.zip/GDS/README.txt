There are no Vt's set in this library (we set them in scripts).
If you want to stream in and merge, you will need to make copies for each Vt and add them to each.
